package com.example.ExampleApiDemo.controller;

import com.example.ExampleApiDemo.model.ResumeData;
import com.example.ExampleApiDemo.model.SkillRequest;
import com.example.ExampleApiDemo.model.SkillResponse;
import com.example.ExampleApiDemo.service.DownloadService;
import com.example.ExampleApiDemo.service.ResumeService;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
@Slf4j
@RequestMapping("api/resume")
@CrossOrigin(origins = "*")

public class ResumeController {
  private final ResumeService resumeService;
  private final DownloadService downloadService;

  public ResumeController(ResumeService resumeService, DownloadService downloadService) {
    this.resumeService = resumeService;
    this.downloadService = downloadService;
  }

  @PostMapping("parse")
  public ResponseEntity<ResumeData> extract(@RequestParam("file") MultipartFile file) throws IOException {
    log.info("parse Controller started by accepting the resume ");
    ResumeData data = resumeService.extractResumeData(file);
    log.info("parse Controller Ending by sending the response");
    return ResponseEntity.ok(data);
  }

  @PostMapping("download-resume")
  public ResponseEntity<byte[]> downloadResume(@RequestBody ResumeData resumeData) throws IOException {
    log.info("Resume download Controller started ");
    byte[] bytes = downloadService.downloadResume(resumeData);
    StringBuilder fileName = getFileName(resumeData);
    log.info("Resume is being downloaded with File name: {}", fileName);
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
    headers.setContentDisposition(
            ContentDisposition.attachment().filename(fileName.toString()).build());
    headers.add("X-Filename", fileName.toString());
    log.info("Resume download Controller Ending ");
    return new ResponseEntity<>(bytes, headers, HttpStatus.OK);
  }
  private StringBuilder getFileName(ResumeData resumeData) {
    log.info("Generating file name for resume");
    String candidateName = StringUtils.defaultString(resumeData.getHeaders().getCandidateName());
    String candidatePosition = StringUtils.defaultString(resumeData.getHeaders().getCandidatePosition());
    log.debug("Candidate name: {}", candidateName);
    log.debug("Candidate position: {}", candidatePosition);
    StringBuilder fileName = new StringBuilder();
    fileName.append("Maveric_");
    fileName.append(candidateName);
    fileName.append("_");
    fileName.append(candidatePosition);
    fileName.append(".docx");
    log.info("Generated file name: {}", fileName);
    return fileName;
  }

  @PostMapping("extract-skills")
  public ResponseEntity<SkillResponse> extractSkills(@RequestBody SkillRequest request) {
    log.info("extract-skills Controller started and Extracting the skills from the resume");
    return ResponseEntity.ok(resumeService.extractSkills(request));
  }

  @PostMapping("parse-raw-resume")
  public ResponseEntity<ResumeData> extractRaw(@RequestParam("file") MultipartFile file) throws IOException {
    log.info("parse-raw-resume Controller started");
    return ResponseEntity.ok(resumeService.extractRawWithFormatterPrompt(file));

  }
}
