package com.example.ExampleApiDemo;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.core.env.Environment;

import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class ExampleApiDemoApplication extends SpringBootServletInitializer {

    // Required for WAR deployment
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(ExampleApiDemoApplication.class);
    }

    public static void main(String[] args) {
        var context = SpringApplication.run(ExampleApiDemoApplication.class, args);
        Environment env = context.getEnvironment();

        try {
            String ipAddress = InetAddress.getLocalHost().getHostAddress();
            String port = env.getProperty("server.port", "8080");
            String appName = env.getProperty("spring.application.name", "Spring Boot App");
            log.info("{} is running at http://{}:{}", appName, ipAddress, port);
        } catch (UnknownHostException e) {
            log.error("Error fetching host IP", e);
        }
    }
}
