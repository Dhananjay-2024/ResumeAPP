package com.example.ExampleApiDemo.service;
import org.apache.tika.Tika;
import org.apache.tika.exception.TikaException;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.example.ExampleApiDemo.exceptions.GeminiException;
import com.example.ExampleApiDemo.model.ResumeData;
import com.example.ExampleApiDemo.model.SkillRequest;
import com.example.ExampleApiDemo.model.SkillResponse;
import com.example.ExampleApiDemo.util.ResumeUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ResumeService {

  @Value("${gemini.api.key}")
  private String apiKey;

  private String API_URL;
  @PostConstruct
  public void init() {
    API_URL = "https://generativelanguage.googleapis.com/v1/models/gemini-2.0-flash:generateContent?key=" + apiKey;
    System.out.println("API Key: " + apiKey); // Debug
  }

  private final RestTemplate restTemplate = new RestTemplate();

  public ResumeData extractResumeData(MultipartFile file) throws IOException {
    log.info("[extractResumeData] Entered method");
    String fileName = file.getOriginalFilename();
    log.debug("[extractResumeData] Uploaded file name: {}", fileName);

    assert fileName != null;
    String extension = fileName.substring(fileName.lastIndexOf(".") + 1).toLowerCase();
    log.debug("[extractResumeData] Extracted file extension: {}", extension);
    String resumeText;

    if ("pdf".equals(extension)) {
      log.info("[extractResumeData] Detected PDF file. Starting PDF extraction.");
      resumeText = extractTextFromPdf(file);
      log.debug("[extractResumeData] Extracted text length from PDF: {}", resumeText.length());
    } else if ("docx".equals(extension)) {
      log.info("[extractResumeData] Detected DOCX file. Starting DOCX extraction.");
      resumeText = extractTextFromDocx(file);
      log.debug("[extractResumeData] Extracted text length from DOCX: {}", resumeText.length());
    } else if ("ppt".equals(extension) || "pptx".equals(extension)){
      log.info("[extractResumeData] Detected PPT file. Starting PPT extraction.");
      resumeText = extractTextFromPpt(file);
      log.debug("[extractResumeData] Extracted text length from PPT: {}", resumeText.length());
    }
    else {
      log.error("[extractResumeData] Unsupported file type: {}", extension);
      throw new IllegalArgumentException("Unsupported file type. Please upload a PDF or DOCX.");
    }

    String prompt = ResumeUtils.RESUME_PROMPT;
    log.debug("[extractResumeData] Prompt used for Gemini request: {}", prompt);

    Map<String, Object> body = Map.of(
            "contents", List.of(
                    Map.of("parts", List.of(
                            Map.of("text", prompt + "\n\n" + resumeText)))),
            "generationConfig", Map.of("temperature", 0.3));
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    log.debug("[extractResumeData] Prepared headers for Gemini API call.");

    HttpEntity<Map<String, Object>> request = new HttpEntity<>(body, headers);
    
    try {
      log.info("[extractResumeData] Sending request to Gemini API");
            ResponseEntity<String> response = restTemplate.postForEntity(API_URL, request, String.class);
      log.debug("[extractResumeData] Received response: {}", response.getBody());

      String jsonResponse = extractJsonFromGeminiResponse(response.getBody());
      log.debug("[extractResumeData] Extracted JSON: {}", jsonResponse);

      ResumeData resumeData = new ObjectMapper().readValue(jsonResponse, ResumeData.class);
      log.info("[extractResumeData] Successfully parsed ResumeData");
      return resumeData;

    } catch (Exception e) {
      log.error("[extractResumeData] Gemini API call failed: {}", e.getLocalizedMessage(), e);
      throw new GeminiException("Error while extracting resume data. Please try again later.", e);
    }
  }

  public ResumeData extractRawWithFormatterPrompt(MultipartFile file) throws IOException {
    log.info("[extractRawWithFormatterPrompt] Entered method");

    String fileName = file.getOriginalFilename();
    log.debug("[extractRawWithFormatterPrompt] Uploaded file name: {}", fileName);

    String extension = fileName.substring(fileName.lastIndexOf(".") + 1).toLowerCase();
    log.debug("[extractRawWithFormatterPrompt] Extracted file extension: {}", extension);

    String resumeText;

    if ("pdf".equals(extension)) {
      log.info("[extractRawWithFormatterPrompt] Detected PDF file. Starting PDF extraction.");
      resumeText = extractTextFromPdf(file);
      log.debug("[extractRawWithFormatterPrompt] Extracted text length from PDF: {}", resumeText.length());
    } else if ("docx".equals(extension)) {
      log.info("[extractRawWithFormatterPrompt] Detected DOCX file. Starting DOCX extraction.");
      resumeText = extractTextFromDocx(file);
      log.debug("[extractRawWithFormatterPrompt] Extracted text length from DOCX: {}", resumeText.length());
    } else if ("ppt".equals(extension) || "pptx".equals(extension)){
      log.info("[extractRawWithFormatterPrompt] Detected PPT file. Starting PPT extraction.");
      resumeText = extractTextFromPpt(file);
      log.debug("[extractRawWithFormatterPrompt] Extracted text length from PPT: {}", resumeText.length());
    }
    else {
      log.error("[extractRawWithFormatterPrompt] Unsupported file type: {}", extension);
      throw new IllegalArgumentException("Unsupported file type. Please upload a PDF or DOCX.");
    }

    String prompt = ResumeUtils.RAW_FORMATTER_PROMPT;
    log.debug("[extractRawWithFormatterPrompt] Prompt used for Gemini request: {}", prompt);

    Map<String, Object> body = Map.of(
            "contents", List.of(
                    Map.of("parts", List.of(
                            Map.of("text", prompt + "\n\n" + resumeText)))),
            "generationConfig", Map.of("temperature", 0.3));

    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    log.debug("[extractRawWithFormatterPrompt] Prepared headers for Gemini API call.");

    HttpEntity<Map<String, Object>> request = new HttpEntity<>(body, headers);

    try {
      log.info("[extractRawWithFormatterPrompt] Sending request to Gemini API");
      ResponseEntity<String> response = restTemplate.postForEntity(API_URL, request, String.class);
      log.debug("[extractRawWithFormatterPrompt] Received response: {}", response.getBody());

      String jsonResponse = extractJsonFromGeminiResponse(response.getBody());
      log.debug("[extractRawWithFormatterPrompt] Extracted JSON: {}", jsonResponse);

      ResumeData resumeData = new ObjectMapper().readValue(jsonResponse, ResumeData.class);
      log.info("[extractRawWithFormatterPrompt] Successfully parsed ResumeData");
      return resumeData;

    } catch (Exception e) {
      log.error("[extractRawWithFormatterPrompt] Gemini API call failed: {}", e.getLocalizedMessage(), e);
      throw new GeminiException("Error while extracting raw resume data. Please try again later.", e);
    }
  }

  private String extractTextFromDocx(MultipartFile file) throws IOException {
    log.info("Starting DOCX text extraction");
    Tika tika = new Tika();
    try {
      String extractedText = tika.parseToString(file.getInputStream());
      log.debug("Extracted text length from DOCX: {}", extractedText.length());
      return extractedText;
    } catch (TikaException e) {
      log.error("Failed to extract text from DOCX: {}", e.getMessage(), e);
      throw new IOException("Failed to extract text from DOCX using Tika", e);
    }
  }

  private String extractTextFromPdf(MultipartFile file) throws IOException {
    log.info("Starting PDF text extraction");
    Tika tika = new Tika();
    try {
      String extractedText = tika.parseToString(file.getInputStream());
      log.debug("Extracted text length from PDF: {}", extractedText.length());
      return extractedText;
    } catch (TikaException e) {
      log.error("Failed to extract text from PDF: {}", e.getMessage(), e);
      throw new IOException("Failed to extract text from PDF using Tika", e);
    }
  }

  private String extractJsonFromGeminiResponse(String responseBody) {
    log.info("Extracting JSON from Gemini API response");
    try {
      ObjectMapper mapper = new ObjectMapper();
      Map<?, ?> map = mapper.readValue(responseBody, Map.class);
      List<?> candidates = (List<?>) map.get("candidates");

      if (!candidates.isEmpty()) {
        Map<?, ?> first = (Map<?, ?>) candidates.get(0);
        Map<?, ?> content = (Map<?, ?>) first.get("content");
        List<?> parts = (List<?>) content.get("parts");

        if (!parts.isEmpty()) {
          Map<?, ?> textPart = (Map<?, ?>) parts.get(0);
          String fullText = textPart.get("text").toString().replace("```", "").replace("json", "");
          log.debug("Extracted JSON text from Gemini response");
          return fullText;
        }
      }
    } catch (Exception e) {
      log.error("Failed to extract JSON from Gemini response: {}", e.getMessage(), e);
      throw new RuntimeException("Failed to extract JSON from Gemini response", e);
    }
    return "{}";
  }

  public SkillResponse extractSkills(SkillRequest request) {
    log.info("Extracting skills using Gemini");
    try {
      String skillPrompt;
      Path path = Paths.get("src/main/resources/templates/skillPrompt.txt");
      skillPrompt = Files.readString(path);
      log.debug("Loaded skill prompt from file");

      String prompt = skillPrompt + "\n\nResume JSON:\n" +
              new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(request.getResumeData()) +
              "\n\nJob Description:\n" + request.getJobDescription();

      Map<String, Object> body = Map.of(
              "contents", List.of(
                      Map.of("parts", List.of(
                              Map.of("text", prompt)))),
              "generationConfig", Map.of("temperature", 0.2));

      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON);

      HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(body, headers);

      log.info("Sending request to Gemini API for skill extraction");
      ResponseEntity<String> response = restTemplate.postForEntity(API_URL, requestEntity, String.class);
      log.debug("Received response from Gemini API");

      String json = extractJsonFromGeminiResponse(response.getBody());
      if (json.startsWith("```json")) json = json.substring(7).trim();
      if (json.endsWith("```")) json = json.substring(0, json.length() - 3).trim();

      SkillResponse skillResponse = new ObjectMapper().readValue(json, SkillResponse.class);
      Collections.sort(skillResponse.getResumeSkill());
      Collections.sort(skillResponse.getMatchedSkills());
      Collections.sort(skillResponse.getRequiredSkills());

      log.info("Successfully extracted and sorted skill data");
      return skillResponse;

    } catch (Exception e) {
      log.error("Failed to extract skills using Gemini: {}", e.getMessage(), e);
      throw new RuntimeException("Failed to extract skills using Gemini", e);
    }
  }

  private String extractTextFromPpt(MultipartFile file) throws IOException {
    log.info("Starting PPT text extraction");
    Tika tika = new Tika();
    try {
      String extractedText = tika.parseToString(file.getInputStream());
      log.debug("Extracted text length from PPT: {}", extractedText.length());
      return extractedText;
    } catch (TikaException e) {
      log.error("Failed to extract text from PPT: {}", e.getMessage(), e);
      throw new IOException("Failed to extract text from PPT using Tika", e);
    }
  }

}
