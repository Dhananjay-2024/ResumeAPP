package com.example.ExampleApiDemo.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import org.apache.poi.xwpf.usermodel.BodyElementType;
import org.apache.poi.xwpf.usermodel.IBodyElement;
import org.apache.poi.xwpf.usermodel.LineSpacingRule;
import org.apache.poi.xwpf.usermodel.XWPFAbstractNum;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFHeader;
import org.apache.poi.xwpf.usermodel.XWPFNumbering;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.apache.xmlbeans.XmlCursor;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTAbstractNum;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTInd;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTLevelText;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTLvl;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTNumFmt;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTPPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTblLayoutType;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTblPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTblWidth;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTcPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STJc;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STNumberFormat;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STTblLayoutType;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STTblWidth;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.example.ExampleApiDemo.model.Credit;
import com.example.ExampleApiDemo.model.ProjectDetail;
import com.example.ExampleApiDemo.model.ProjectExperience;
import com.example.ExampleApiDemo.model.ResumeData;

import lombok.extern.slf4j.Slf4j;
import static ch.qos.logback.core.util.StringUtil.capitalizeFirstLetter;

@Service
@Slf4j
public class DownloadService {

	public byte[] downloadResume(ResumeData resumeData) {
		try (XWPFDocument document = new XWPFDocument(new ClassPathResource("Maveric_Template.docx").getInputStream());
			 ByteArrayOutputStream out = new ByteArrayOutputStream()) {

			// Process headers
			if (resumeData.getHeaders() != null) {
				processHeaders(document.getHeaderList(),
						resumeData.getHeaders().getCandidateName(),
						resumeData.getHeaders().getCandidatePosition());
			} else {
				log.warn("Headers section is missing in ResumeData.");
			}
			// Process summary
			processSummary(document, "SUMMARY", resumeData.getProfessionalSummary());

			// Process bullet list
			processBulletList(document, "EXPERIENCE", resumeData.getProfessionalExperience());

			// Process bullet list
			processBulletList(document, "AWARDS", resumeData.getAwards());

			// Process certifications
			processBulletList(document, "CERTIFICATION", resumeData.getCertifications());

			// Process educations
			processBulletList(document, "EDUCATION", resumeData.getEducation());

			// Process credits
			processCreditTable(document, "CREDITS", resumeData.getCredits());

			// Process project experience
			processProjectExperienceTable(document, "PROJECT_EXPERIENCE",
					resumeData.getProjectExperience());

			// Remove blank sections
			removeBlankSections(document, resumeData);

			document.write(out);
			return out.toByteArray();

		} catch (IOException e) {
			log.error("Error while creating file: ", e);
		}
		return new byte[0];
	}

	private void removeBlankSections(XWPFDocument doc, ResumeData resumeData) {

		if (resumeData.getAwards() == null || (resumeData.getAwards() != null && resumeData.getAwards().isEmpty())) {
			log.debug("Removing section: Awards & Recognitions as it's empty or null");
			removeSection("Awards & Recognitions", doc);
		}
		if (resumeData.getCertifications() == null
				|| (resumeData.getCertifications() != null && resumeData.getCertifications().isEmpty())) {
			log.debug("Removing section: Certifications and Courses as it's empty or null");
			removeSection("Certifications and Courses", doc);
		}
		if (resumeData.getEducation() == null
				|| (resumeData.getEducation() != null && resumeData.getEducation().isEmpty())) {
			log.debug("Removing section: Educational Qualification as it's empty or null");
			removeSection("Educational Qualification", doc);
		}
		if (resumeData.getCredits() == null
				|| (resumeData.getCredits() != null && resumeData.getCredits().isEmpty())) {
			log.debug("Removing section: Credits as it's empty or null");
			removeSection("Credits", doc);
		}
		if (resumeData.getProjectExperience() == null
				|| (resumeData.getProjectExperience() != null && resumeData.getProjectExperience().isEmpty())) {
			log.debug("Removing section: Project Experience as it's empty or null");
			removeSection("Project Experience", doc);
		}
	}

	private void removeSection(String sectionName, XWPFDocument doc) {
		log.debug("Attempting to remove section: {}", sectionName);
		List<IBodyElement> bodyElements = doc.getBodyElements();

		for (int i = 0; i < bodyElements.size(); i++) {
			IBodyElement element = bodyElements.get(i);

			if (element.getElementType() == BodyElementType.PARAGRAPH) {
				XWPFParagraph paragraph = (XWPFParagraph) element;
				String text = paragraph.getText().trim();
				log.debug("Checking paragraph text: '{}'", text);

				if (sectionName.equalsIgnoreCase(text)) {
					log.debug("Matched section: '{}'", text);
					// Check for shading
					CTPPr pPr = paragraph.getCTP().getPPr();
					if (pPr != null && pPr.isSetShd()) {
						log.debug("Shading detected for '{}', removing paragraph.", sectionName);
						doc.removeBodyElement(i);
						i--; // Adjust index after removal
					} else {
						log.debug("No shading found for '{}', paragraph not removed.", sectionName);
					}
				}
			}
		}
		log.debug("Finished processing section: {}", sectionName);
	}
	private void processProjectExperienceTable(XWPFDocument doc, String placeholder,
			List<ProjectExperience> projectExperience) {
		log.debug("Starting processProjectExperienceTable with placeholder: {}", placeholder);
		List<XWPFParagraph> paragraphs = doc.getParagraphs();
		for (int i = 0; i < paragraphs.size(); i++) {
			XWPFParagraph paragraph = paragraphs.get(i);
			String text = paragraph.getText();
			log.debug("Checking paragraph {} with text: {}", i, text);
			if (text.contains(placeholder)) {
				log.debug("Found placeholder in paragraph {}", i);
				// Remove runs containing the placeholder text
				for (XWPFRun run : paragraph.getRuns()) {
					if (run.getText(0) != null && run.getText(0).contains(placeholder)) {
						log.debug("Clearing placeholder text in run: {}", run.getText(0));
						run.setText("", 0); // Clear the placeholder text
					}
				}
				// Insert table right after the paragraph
				XmlCursor cursor = paragraph.getCTP().newCursor();
				XWPFTable table = doc.insertNewTbl(cursor);
				log.debug("Inserted new table after placeholder");
				// Set fixed table width and layout
				CTTblPr tblPr = table.getCTTbl().addNewTblPr();
				CTTblWidth tblWidth = tblPr.addNewTblW();
				tblWidth.setW(BigInteger.valueOf(9000)); // Total width
				tblWidth.setType(STTblWidth.DXA);       // DXA = fixed units
				CTTblLayoutType layout = tblPr.addNewTblLayout();
				layout.setType(STTblLayoutType.FIXED);
				// Add data rows
				for (ProjectExperience experience : projectExperience) {
					log.debug("Processing ProjectExperience: {}", experience);
					XWPFTableRow row = table.createRow();
					// Ensure all cells are created before setting text
					XWPFTableCell cell0 = row.getCell(0);
					if (cell0 == null) {
						cell0 = row.createCell();
					}
					cell0.removeParagraph(0);
					XWPFParagraph para = cell0.addParagraph();
					for (ProjectDetail item : experience.getProjectDetails()) {
						log.debug("Adding ProjectDetail: {} = {}", item.getKey(), item.getValue());
						if (item.getValue() instanceof String) {
							createCellOfClientColumn(item.getValue().toString(), capitalizeFirstLetter(item.getKey()) + ": ", para);
						} else if (item.getValue() instanceof List<?>) {
							createCellOfClientColumn(
									String.join(", ",
											Objects.requireNonNullElse(
													Arrays.asList(item.getValue().toString().split(",")),
													Collections.emptyList())),
									capitalizeFirstLetter(item.getKey()) + ": ",
									para);
						}
					}
					// Set width for first column
					CTTcPr tcPr = cell0.getCTTc().addNewTcPr();
					CTTblWidth width = tcPr.addNewTcW();
					width.setW(BigInteger.valueOf(2700));
					width.setType(STTblWidth.DXA);
					cell0.getCTTc().addNewTcPr().addNewShd().setFill("d8d4d4");
					XWPFTableCell cell1 = row.getCell(1);
					if (cell1 == null) {
						cell1 = row.createCell();
					}
					CTTcPr tcPr2 = cell1.getCTTc().addNewTcPr();
					CTTblWidth width2 = tcPr2.addNewTcW();
					width2.setW(BigInteger.valueOf(6300));
					width2.setType(STTblWidth.DXA);
					cell1.removeParagraph(0);
					para = cell1.addParagraph();
					createDescriptionCell(experience.getDescription(), "Description: ", para);
					createResponsibilitiesCell(experience.getResponsibilities(), "Responsibilities: ", doc, cell1);
				}
				if (table.getNumberOfRows() > 0) {
					table.removeRow(0);
					log.debug("Removed first empty row from table");
				}
				break;
			}
		}
		log.debug("Finished processProjectExperienceTable for placeholder: {}", placeholder);
	}
	private void createCellOfClientColumn(String value, String label, XWPFParagraph para) {
		log.debug("Creating cell with label: '{}' and value: '{}'", label, value);

		if (StringUtils.hasText(value)) {
			XWPFRun labelRun = para.createRun();
			labelRun.setBold(true);
			labelRun.setText(label);
			XWPFRun valueRun = para.createRun();
			valueRun.setBold(false);
			valueRun.setText(value);
			valueRun.addBreak();

			log.debug("Successfully added label and value to paragraph.");
		} else {
			log.debug("Skipped empty or blank value for label: '{}'", label);
		}
	}
	private void createDescriptionCell(String value, String label, XWPFParagraph para) {
		log.debug("Creating description cell with label: '{}' and value: '{}'", label, value);

		if (StringUtils.hasText(value)) {
			XWPFRun labelRun = para.createRun();
			labelRun.setBold(true);
			labelRun.setText(label);
			labelRun.addBreak();

			XWPFRun valueRun = para.createRun();
			valueRun.setBold(false);
			valueRun.setText(value);
			valueRun.addBreak();
			valueRun.addBreak();

			log.debug("Successfully added description content to paragraph.");
		} else {
			log.debug("Skipped description cell creation due to empty or null value for label: '{}'", label);
		}
	}
	private void createResponsibilitiesCell(List<String> values, String label, XWPFDocument doc, XWPFTableCell cell) {
		log.debug("Creating responsibilities cell with label: '{}' and values: {}", label, values);

		if (values != null && !values.isEmpty()) {
			log.debug("Values are present, proceeding with responsibilities cell creation.");

			// Get the first paragraph (default) inside the cell
			XWPFParagraph labelPara = cell.getParagraphs().get(0);
			XWPFRun labelRun = labelPara.createRun();
			labelRun.setBold(true);
			labelRun.setText(label);
			labelPara.setSpacingAfter(0);

			// Create numbering if not exists
			XWPFNumbering numbering = doc.getNumbering();
			if (numbering == null) {
				numbering = doc.createNumbering();
				log.debug("Created new numbering instance.");
			}
			// Create bullet list style if not exists
			BigInteger numId = getOrCreateBulletNumbering(doc, numbering);
			log.debug("Using bullet list style with numId: {}", numId);
			// Add bullets
			for (String value : values) {
				log.debug("Adding responsibility bullet: {}", value);

				XWPFParagraph bulletPara = cell.addParagraph();
				bulletPara.setNumID(numId);
				bulletPara.setSpacingBefore(0);
				bulletPara.setSpacingAfter(0);
				bulletPara.setSpacingBetween(1.0, LineSpacingRule.AUTO);
				XWPFRun bulletRun = bulletPara.createRun();
				bulletRun.setText(value);
			}

			log.debug("Finished adding all responsibilities.");
		} else {
			log.debug("No responsibilities provided. Skipping cell creation.");
		}
	}
	private void processCreditTable(XWPFDocument doc, String placeholder, List<Credit> credits) {
		log.debug("Processing credit table with placeholder: {}", placeholder);
		List<IBodyElement> bodyElements = new ArrayList<>(doc.getBodyElements());
		for (int i = 0; i < bodyElements.size(); i++) {
			IBodyElement element = bodyElements.get(i);
			if (element instanceof XWPFParagraph) {
				XWPFParagraph paragraph = (XWPFParagraph) element;
				String text = paragraph.getText();
				log.debug("Checking paragraph: {}", text);
				if (text != null && text.contains(placeholder)) {
					log.debug("Found placeholder '{}' in paragraph. Removing it and inserting table.", placeholder);
					int pos = doc.getPosOfParagraph(paragraph);
					doc.removeBodyElement(pos);
					XmlCursor cursor = doc.getParagraphArray(pos).getCTP().newCursor();
					XWPFTable table = doc.insertNewTbl(cursor);
					CTTblPr tblPr = table.getCTTbl().addNewTblPr();
					CTTblWidth tblWidth = tblPr.addNewTblW();
					tblWidth.setW(BigInteger.valueOf(9000));
					tblWidth.setType(STTblWidth.DXA);
					CTTblLayoutType layout = tblPr.addNewTblLayout();
					layout.setType(STTblLayoutType.FIXED);
					for (Credit credit : credits) {
						log.debug("Processing credit: {}", credit.getCategory());

						if (StringUtils.hasText(credit.getCategory()) && !credit.getItems().isEmpty()) {
							XWPFTableRow row = table.createRow();
							XWPFTableCell cell1 = row.getCell(0);
							CTTcPr tcPr = cell1.getCTTc().addNewTcPr();
							CTTblWidth width = tcPr.addNewTcW();
							width.setW(BigInteger.valueOf(2700));
							width.setType(STTblWidth.DXA);
							cell1.getCTTc().addNewTcPr().addNewShd().setFill("d8d4d4");
							XWPFParagraph paragraph1 = cell1.getParagraphArray(0);
							XWPFRun run = paragraph1.createRun();
							run.setBold(true);
							run.setText(credit.getCategory());
							XWPFTableCell cell2 = row.addNewTableCell();
							CTTcPr tcPr2 = cell2.getCTTc().addNewTcPr();
							CTTblWidth width2 = tcPr2.addNewTcW();
							width2.setW(BigInteger.valueOf(6300));
							width2.setType(STTblWidth.DXA);

							cell2.setText(String.join(", ", credit.getItems()));
							log.debug("Added row for credit category '{}' with items: {}", credit.getCategory(), credit.getItems());
						}
					}

					table.removeRow(0);
					log.debug("Credit table insertion completed. Exiting loop.");
					break;
				}
			}
		}
	}
	private void processHeaders(List<XWPFHeader> headerList, String name, String position) {
		log.debug("Processing headers with name: {} and position: {}", name, position);

		for (XWPFHeader header : headerList) {
			log.debug("Processing a header with {} tables", header.getTables().size());

			for (XWPFTable table : header.getTables()) {
				for (XWPFTableRow row : table.getRows()) {
					List<XWPFTableCell> cells = row.getTableCells();
					log.debug("Processing table row with {} cells", cells.size());

					if (cells.size() >= 2) {
						log.debug("Replacing 'NAME' with '{}' and 'POSITION' with '{}'", name, position);
						replaceTextInCell(cells.get(0), "NAME", name);
						replaceTextInCell(cells.get(1), "POSITION", position);
					}
				}
			}
		}

		log.debug("Completed processing headers.");
	}
	private void processSummary(XWPFDocument document, String placeholder, String summary) {
		log.debug("Starting summary processing. Placeholder: '{}', Summary: '{}'", placeholder, summary);

		// Replace in body paragraphs
		List<XWPFParagraph> paragraphs = document.getParagraphs();
		log.debug("Processing {} paragraphs in document body", paragraphs.size());
		for (XWPFParagraph paragraph : paragraphs) {
			replaceInParagraph(paragraph, placeholder, summary);
		}
		// Replace in body tables
		List<XWPFTable> tables = document.getTables();
		log.debug("Processing {} tables in document body", tables.size());
		for (XWPFTable table : tables) {
			for (XWPFTableRow row : table.getRows()) {
				for (XWPFTableCell cell : row.getTableCells()) {
					for (XWPFParagraph paragraph : cell.getParagraphs()) {
						replaceInParagraph(paragraph, placeholder, summary);
					}
				}
			}
		}
		log.debug("Completed summary processing.");
	}
	private void processBulletList(XWPFDocument doc, String placeholder, List<String> bulletPoints) {
		log.debug("Starting processBulletList with placeholder: '{}' and {} bullet points", placeholder, bulletPoints.size());

		List<XWPFParagraph> paragraphs = doc.getParagraphs();
		log.debug("Found {} paragraphs in the document", paragraphs.size());
		XWPFNumbering numbering = doc.getNumbering();
		if (numbering == null) {
			numbering = doc.createNumbering();
			log.debug("Created new numbering as none existed");
		}
		BigInteger numId = getOrCreateBulletNumbering(doc, numbering);
		log.debug("Using bullet numbering ID: {}", numId);
		for (int i = 0; i < paragraphs.size(); i++) {
			XWPFParagraph para = paragraphs.get(i);
			String text = para.getText();
			if (text != null && text.contains(placeholder)) {
				log.debug("Found placeholder '{}' in paragraph index {}", placeholder, i);

				int pos = doc.getPosOfParagraph(para);
				doc.removeBodyElement(pos);
				log.debug("Removed placeholder paragraph at position {}", pos);
				for (int j = 0; j < bulletPoints.size(); j++) {
					XmlCursor cursor;
					if (pos + j < doc.getParagraphs().size()) {
						cursor = doc.getParagraphArray(pos + j).getCTP().newCursor();
					} else {
						cursor = doc.getDocument().getBody().newCursor();
						log.debug("Using fallback cursor at end of document for index {}", j);
					}
					XWPFParagraph newPara = doc.insertNewParagraph(cursor);
					newPara.setNumID(numId);
					newPara.setSpacingBefore(0);
					newPara.setSpacingAfter(0);
					newPara.setSpacingBetween(1.0, LineSpacingRule.AUTO);
					XWPFRun run = newPara.createRun();
					run.setText(bulletPoints.get(j));

					log.debug("Inserted bullet point: '{}'", bulletPoints.get(j));
				}
				log.debug("Completed bullet insertion for placeholder '{}'", placeholder);
				break;
			}
		}

		log.debug("Finished processBulletList");
	}
	private BigInteger getOrCreateBulletNumbering(XWPFDocument doc, XWPFNumbering numbering) {
		log.debug("Entered getOrCreateBulletNumbering");
		// Try to reuse existing numbering if available
		for (XWPFAbstractNum absNum : numbering.getAbstractNums()) {
			CTAbstractNum ctAbsNum = absNum.getCTAbstractNum();
			if (ctAbsNum.getLvlArray(0).getNumFmt().getVal() == STNumberFormat.BULLET) {
				BigInteger abstractNumId = ctAbsNum.getAbstractNumId();
				log.debug("Found existing bullet numbering with abstractNumId: {}", abstractNumId);
				return numbering.addNum(abstractNumId);
			}
		}
		log.debug("Creating new bullet numbering");
		// Create new bullet numbering
		CTAbstractNum abstractNum = CTAbstractNum.Factory.newInstance();
		abstractNum.setAbstractNumId(BigInteger.valueOf(numbering.getAbstractNums().size())); // unique id
		CTLvl lvl = abstractNum.addNewLvl();
		lvl.setIlvl(BigInteger.ZERO);

		CTNumFmt numFmt = lvl.addNewNumFmt();
		numFmt.setVal(STNumberFormat.BULLET);

		CTLevelText lvlText = lvl.addNewLvlText();
		lvlText.setVal("•"); // bullet symbol

		lvl.addNewLvlJc().setVal(STJc.LEFT);

		CTInd ind = lvl.addNewPPr().addNewInd();
		ind.setLeft(BigInteger.valueOf(720)); // indent
		ind.setHanging(BigInteger.valueOf(360)); // hanging indent

		XWPFAbstractNum bulletAbstractNum = new XWPFAbstractNum(abstractNum);

		BigInteger abstractNumID = numbering.addAbstractNum(bulletAbstractNum);
		BigInteger numId = numbering.addNum(abstractNumID);
		log.debug("Created new bullet numbering with numId: {}", numId);
		return numId;
	}
	private void replaceInParagraph(XWPFParagraph paragraph, String placeholder, String summary) {
		log.debug("Replacing placeholder '{}' with summary text in paragraph", placeholder);
		if (StringUtils.hasText(summary)) {
			for (XWPFRun run : paragraph.getRuns()) {
				String text = run.getText(0);
				if (text != null) {
					if (text.contains(placeholder)) {
						log.debug("Found placeholder '{}' in text: '{}'", placeholder, text);
						text = text.replace(placeholder, summary);
					}
					run.setText(text, 0);
				}
			}
		}
	}
	private void replaceTextInCell(XWPFTableCell cell, String placeholder, String value) {
		log.debug("Replacing placeholder '{}' with value '{}' in cell", placeholder, value);
		if (StringUtils.hasText(value)) {
			for (XWPFParagraph paragraph : cell.getParagraphs()) {
				for (XWPFRun run : paragraph.getRuns()) {
					String text = run.getText(0);
					if (text != null && text.contains(placeholder)) {
						log.debug("Found placeholder '{}' in run text: '{}'", placeholder, text);
						run.setText(text.replace(placeholder, value), 0);
					}
				}
			}
		}
	}

}
