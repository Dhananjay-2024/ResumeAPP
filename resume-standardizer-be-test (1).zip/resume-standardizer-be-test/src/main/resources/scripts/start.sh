#!/bin/bash

echo "Starting the application (background script from target directory)..."

# The JAR file name as defined in pom.xml or by Spring Boot Maven Plugin
ARTIFACT_ID="resume-standardizer"
VERSION="0.0.1-SNAPSHOT" # Ensure this matches your pom.xml
JAR_FILE="${ARTIFACT_ID}-${VERSION}.jar"
PID_FILE="app.pid"
LOG_FILE="app.log"

# This script expects to be in the same directory as the JAR (e.g., 'target')
if [[ ! -f "$JAR_FILE" ]]; then
  echo "Error: JAR file '$JAR_FILE' not found in the current directory ($(pwd))."
  echo "Ensure this script is run from the 'target' directory after a successful build."
  exit 1
fi

# Check if app.pid exists and if the process is still running
if [ -f $PID_FILE ]; then
    PID=$(cat $PID_FILE)
    if ps -p $PID > /dev/null; then
        echo "Application is already running with PID $PID."
        exit 0
    else
        echo "Warning: PID file '$PID_FILE' found, but process $PID is not running. Removing stale PID file."
        rm -f $PID_FILE
    fi
fi

echo "Starting $JAR_FILE in background..."
nohup java -jar "$JAR_FILE" > "$LOG_FILE" 2>&1 &
echo $! > "$PID_FILE"

# Small delay to allow the application to start and potentially fail fast
sleep 3

if ps -p $(cat $PID_FILE) > /dev/null; then
    echo "Application started successfully in background."
    echo "PID: $(cat $PID_FILE)"
    echo "Logs are in: $(pwd)/$LOG_FILE"
else
    echo "Failed to start the application. Check $LOG_FILE for details."
    # Clean up pid file if startup failed
    if [ -f $PID_FILE ]; then
        rm -f $PID_FILE
    fi
    exit 1
fi