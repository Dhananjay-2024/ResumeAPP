#!/bin/bash

PID_FILE="app.pid"

if [ -f $PID_FILE ]; then
  PID=$(cat $PID_FILE)
  echo "Stopping application with PID $PID..."
  if ps -p $PID > /dev/null; then
    kill $PID
    # Wait a bit for the process to terminate
    sleep 2
    if ps -p $PID > /dev/null; then
      echo "Application did not stop gracefully, sending SIGKILL..."
      kill -9 $PID
      sleep 1
    fi
    rm -f $PID_FILE
    echo "Application stopped."
  else
    echo "Process with PID $PID not found. Removing stale PID file."
    rm -f $PID_FILE
  fi
else
  echo "No PID file found ($PID_FILE). Application may not be running or was not started with start.sh."
fi