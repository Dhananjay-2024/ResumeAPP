#!/bin/bash
# This script expects to be in the same directory as start.sh and stop.sh (e.g., 'target')

echo "Attempting to restart the application..."

SCRIPT_DIR=$(dirname "$0") # Get the directory where the script is located

# Ensure stop.sh and start.sh are executable and exist
if [ ! -x "$SCRIPT_DIR/stop.sh" ]; then
    echo "Error: stop.sh not found or not executable in $SCRIPT_DIR"
    exit 1
fi
if [ ! -x "$SCRIPT_DIR/start.sh" ]; then
    echo "Error: start.sh not found or not executable in $SCRIPT_DIR"
    exit 1
fi

"$SCRIPT_DIR/stop.sh"
echo "Waiting for 2 seconds before starting..."
sleep 2
"$SCRIPT_DIR/start.sh"

echo "Restart process initiated."